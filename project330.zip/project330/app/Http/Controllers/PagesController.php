<?php

namespace App\Http\Controllers;

//Import EVERYTHING!
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\User;
use App\Post;
use App\Likes;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;


//This controller is for loading pages + login/logout of users
class PagesController extends Controller
{
    //Return the welcome view
    public function home(){
        return view('welcome');
    }
    
    //Return the about website view
    public function about(){
        return view('about');
    }
    
    //function to register a user
    public function register(Request $request){
        //make sure the fields are filled out and meet our requirements
        $this->validate($request, [
            //username is at most 100 characters and must be unique
            'name' => 'required|max:100|unique:users',
            //password is at least 4 characters.  I'm running a super secure app here.  3 letters is unacceptable.  16 characters most
            'password' => 'required|min:4|max:16'
        ]);
        
        //get the username and password that the user inputted
        $username=$request['name'];
        $password=bcrypt($request['password']);//let's encrypt the password while we're at it
        
        //Add a new entry for the user in the database.  Fill out the name and password fields
        $user = new User();
        $user->name=$username;
        $user->password=$password;
        
        //save the entry
        $user->save();
        
        //authenticate the user so that they can actually do things on the site
        Auth::login($user);
        
        //redirect the user to the dashboard
        return redirect()->route('dashboard');
    }
    
    
    //function to sign in a user that already has an account
    public function signIn(Request $request){
        //make sure that the user actually filled out username and password fields
        $this->validate($request, [
            'l_username' => 'required',
            'l_password' => 'required'
        ]);
        
        //check to see if the user/password combination is valid
        if (Auth::attempt( ['name' => $request['l_username'],
                            'password' => ($request['l_password'])] )){
            //if valid, redirect them to the dashboard
            return redirect()->route('dashboard');
        }
        //if invalid, return them back to login
        return redirect()->back();
    }
    
    //function to logout the user and return them home (login)
    public function logout(){
        Auth::logout();
        return redirect()->route('home');
    }
    
    //return settings page for the currently logged-in user
    public function accountInfo(){
        return view('account', ['user'=>Auth::user()]);
    }
    
    //function to update the user's image and description
    public function accountUpdate(Request $request){
        //make sure the inupt is valid (max 3000 chars for description, image must be png and 100kb max)
        $this->validate($request, [
            'description' => 'max:1000',
            'image' => 'max:200|mimes:png',
        ]);
        //get the current user
        $user = Auth::user();
        
        //update description in the database
        $user->description=$request['description'];
        $user->update();
        
        //get the image
        $file = $request->file('image');
        
        //if we got a file, put it in storage
        if($file){
            //set the filename (userid + .png)
            $filename = $user->id . '.png';
            Storage::disk('local')->put($filename, File::get($file));
        }
        //refresh the page
        return redirect()->route('accountInfo');
    }
    
    //function to retrieve an image
    public function getimg($filename){
        $file = Storage::disk('local')->get($filename);
        return new Response($file, 200);
    }
    
}

