<?php

namespace App\Http\Controllers;

//Import EVERGYTHINGGGG
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Post;
use App\User;
use App\Likes;

//This controller is for loading stuff invovling actual posts
class PostsController extends Controller
{
    //Ok these two were supposed to be in PagesController, but I had to put them here to get a few functions I called in views to work
    //Retrieve user info for the user info page
    public function userInfo($userV){
        //get the user
        $user = User::where('name', $userV)->get()->first();
        //get the user's posts
        $posts = Post::where('user_id', $user->id)->orderBy('created_at', 'desc')->get();
        return view('viewuser',['user'=>$user,'posts'=>$posts]);
    }
    
    //Get all posts in descending order and send them to the dashboard
    public function dashboardView(){
        $posts = Post::orderBy('created_at', 'desc')->get();
        return view('dashboard', ['posts'=>$posts]);//redirect the user to the dashboard
    }
    
    //function to create a new post
    public function createPost(Request $request){
        //make sure the post fits our requirements
        $this->validate($request, [
            'newPost' => 'required|max:1000' 
        ]);
        
        //make a new entry in the database and add the user-inputted content
        $post = new Post();
        $post -> content = $request['newPost'];
        
        //assume something went wrong
        $message= 'There was an error.  Sorry.';
        
        //try to save the post (also add the user who created the post)
        if( $request -> user() -> posts() -> save($post) ){
            //if it saved ok, update the message
            $message = 'Post successfully created!';
        }
        //redirect to the dashboard and print out the message
        return redirect()->route('dashboard')->with(['message' => $message]);
    }
    
    //function to like the post
    public function likePost(Request $request){
        //get ID of the post that was liked
        $postID = $request['postid'];
        //use the ID to retrieve the post
        $post = Post::find($postID);
        //If the post somehow doesn't exist, return null
        if ( !$post ){
            return null;
        }
        
        //get the current user
        $user = Auth::user();
        //check to see if the user has already liked the post
        $likeExists = Likes::where('postID', "=", $postID)->where('userID', '=', $user->id)->first();
        if($likeExists){
            //if the user already liked the post, unlike the post by deleting the entry
            $likeExists->delete();
        }
        else{
            //if the user has yet to like the post, add an entry into the database
            $like = new Likes();
            $like->userID = $user->id;
            $like->postID = $post->id;
            $like->save();
        }
    }
    
    //function to see if the user has already liked the post
    public static function beenLiked($post){
        //get the current user and ID of the post of interest
        $user = Auth::user();
        $postID = $post->id;
        
        //check the Likes table to see if an entry already exists (exists=already liked)
        $likeExists = Likes::where('postID', "=", $postID)->where('userID', '=', $user->id)->first();
        $text = '';
        //return the appropriate options in the form of text.  
        if($likeExists){
            $text='Unlike';//If already liked, give the user the option to unlike.
        }
        else{
            $text='Like';//If not already liked, give the user the option to like
        }
        return $text;
    }
    
    //get the number of likes a post already has
    public static function getLikeCount($post){
        $text="0";
        //count the rows in the Likes table that have the postID col equal to the id of the post passed to the function
        $count=Likes::where('postID', $post->id)->count();
        if($count){
            $text=$count;
        }
        return $text;
    }
    
    //function to edit the post
    public function editPost(Request $request){
        //make sure the new post actually has content (no empty posts allowed)
        $this->validate($request, [
           'content' => 'required|max:1000'
        ]);
        
        //get the post to be edited using the ID passed by the request
        $post = Post::find($request['id']);
        
        //Make sure the current user is the user that created the post
        if(Auth::user() != $post->user){
            return redirect()->back() -> with(['message' => 'How did you even get this error.  The webmaster is disappointed.']);
        }
        //update the post content
        $post-> content = $request['content'];
        $post -> update();
        return response() -> json(['updated_content' => $post->content], 200);
    }
    
    //function to delete a post
    public function deletePost($postID){
        //retrieve the post
        $post = Post::where('id', $postID) -> first();
        //Make sure the current user is the user that created the post
        if(Auth::user() != $post->user){
            return redirect()->back() -> with(['message' => 'How did you even get this error.  The webmaster is disappointed.']);
        }
        //if everything looks good, delete the post and refresh the page with a message
        $post -> delete();
        return redirect() -> route('dashboard') -> with(['message' => 'Post successfully deleted']);
    }
}

