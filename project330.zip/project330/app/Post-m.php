<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post-m extends Model
{
    //
}
