<?php

namespace App;

//use Illuminate\Notifications\Notifiable;
//use Illuminate\Foundation\Auth\User as Authenticatable;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;


//class User extends Authenticatable
class User extends Model implements Authenticatable
{
    use \Illuminate\Auth\Authenticatable;
    //each user can have many posts and many likes
    public function posts(){
        return $this->hasMany('App\Post');
    }
    public function likes(){
        return $this->hasMany('App\Likes');
    }
}
