<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //each post has one user that created it
    public function user(){
        return $this->belongsTo('App\User');
    }
    
    //each post has many likes
    public function likes(){
        return $this->hasMany('App\Likes');
    }
}
