<!--Message Output-->
<!--Errors-->
@if(count($errors) > 0)
        <div class="row">
            <div class="col-md-4 col-md-offset-4 error">
                <u1>
                    @foreach($errors->all() as $error)
                        <li>{{$error}}</li>
                    @endforeach
                </u1>
            </div>
        </div>
@endif
<!--Success Messages-->
@if(Session::has('message'))
        <div class="row">
            <div class="col-md-4 col-md-offset-4 success">
                <u1>
                    {{ Session::get('message') }}
                </u1>
            </div>
        </div>
@endif