@extends('layout')

@section('title')
    About
@endsection

@section('content')
    <h1>About</h1>
        Help what am I doing
@endsection