@extends('layout')

@section('title')
    Facebird
@endsection

@section('content')
    <h1>Welcome to the Facebird:  the social media site for birds</h1>
        @include('messageoutput')
        <div class="row">
            <!--Registration Form-->
            <div class="col-md-3">
                <h3>Register</h3>
                <form action="{{ route('register') }}" method="post">
                    <div class="form-group">
                        <label for="r_username">Username:  </label>
                        <input class="form-control" type="text" name="name" id="r_username" value="{{ Request::old('r_username') }}"> 
                    </div>
                    <div class="form-group">
                        <label for="r_password">Password (4-16 characters):  </label>
                        <input class="form-control" type="password" name="password" id="r_password"> 
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <input type="hidden" name="_token" value="{{ Session::token() }}">
                </form>
            </div>
                
              
            <!--Sign In Form-->
            <div class="col-md-3">
                <h3>Sign In</h3>
                <form action="{{ route('signIn') }}" method="post">
                    <div class="form-group">
                        <label for="l_username">Username:  </label>
                        <input class="form-control" type="text" name="l_username" id="l_username"> 
                    </div>
                    <div class="form-group">
                        <label for="l_password">Password:  </label>
                        <input class="form-control" type="password" name="l_password" id="l_password"> 
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <input type="hidden" name="_token" value="{{ Session::token() }}">
                </form>
            </div>
        
        <!--Show a cute bird pic-->
            <img src="{{ route('account_image', ['image.jpg']) }}" alt="" class="userimage">
        </div>
@endsection
