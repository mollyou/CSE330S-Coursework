<!--Profile page for a given user-->
@extends('layout')

@section('title')
    {{$user->name}}'s profile
@endsection

@section('content')
        <div class="row new-post">
            <div class="col-md-5 col-md-offset-2">
            <!--Description-->
                <header><h3>{{$user->name}}'s profile</h3></header>
                <!--If they have a desctipion, display it.  Otherwise, placeholder-->
                <div class="post">
                    @if($user->description)
                        {{$user->description}}
                    @else
                        <i>No description yet</i>
                    @endif
                    
                </div>
            </div>
            <div class="col-md-4">
                <!--User image.  If they don't have one, show the default-->
                    @if(Storage::disk('local')->has($user -> id.'.png'))
                        <img src=" {{ route('account_image', ['filename' => $user -> id .'.png']) }}" alt="" class="userimage">
                    @else
                        <img src=" {{ route('account_image', ['default.png']) }}" alt="" class="userimage">
                    @endif
            </div>
        </div>
    <!--Display their posts in decending order-->
    <div class="row posts">
        <div class="col-md-6 col-md-offset-3">
            <header><h3>{{$user->name}}'s recent activity</h3></header>
                <!--Go through each post-->
                @foreach($posts as $post)
                    <div class="post" id="{{ $post->id }}">
                    <!--User avatar-->
                         @if(Storage::disk('local')->has($post -> user -> id.'.png'))
                            <img src=" {{ route('account_image', ['filename' => $post -> user -> id .'.png']) }}" alt="" class="avatar">
                         @else
                            <img src=" {{ route('account_image', ['default.png']) }}" alt="" class="avatar">
                         @endif
                    <!--Post body-->
                        <p>{{ $post -> content }}</p>
                    <!--Display post date and number of likes-->
                        <div class="info">
                            Posted on {{ $post -> created_at }}<br>
                            Likes: <p class="inline">{{app\Http\Controllers\PostsController::getLikeCount($post)}}</p>
                        </div>
                    </div>
                @endforeach
        </div>
    </div>
@endsection
    