<?php
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    $pokemon = ['Mimikyu','Nebby','Primarina'];
    return view('welcome', compact('pokemon'));
});
*/
//Route::group( ['middleware' => ['web']], function() {
    Route::get('/',function(){
        return view('welcome');
    })->name('home');
    
    Route::get('/home',function(){
        return view('welcome');
    });
    
    Route::post('/register',[
        'uses' => 'PagesController@register',
        'as' =>'register'
    ]);
    
    Route::post('/signin',[
        'uses' => 'PagesController@signIn',
        'as' =>'signIn'
    ]);
    
    Route::get('/logout',[
        'uses' => 'PagesController@logout',
        'as' =>'logout'
    ]);
    
    Route::get('/dashboard',[
        'uses' => 'PostsController@dashboardView',
        'as' => 'dashboard',
        'middleware' => 'auth'
    ]);
    
    Route::get('/account',[
        'uses' => 'PagesController@accountInfo',
        'as' => 'accountInfo',
        'middleware' => 'auth'
    ]);
    
    Route::post('/updateAccount',[
        'uses' => 'PagesController@accountUpdate',
        'as' => 'account_save',
        'middleware' => 'auth'
    ]);
    
    Route::get('/accountImage/{filename}',[
       'uses' =>'PagesController@getimg',
       'as' => 'account_image'
    ]);
    
    Route::get('/user/{username}',[
       'uses' =>'PostsController@userInfo',
       'as' => 'viewuser',
    ]);
    
    
    Route::post('/createpost', [
       'uses' => 'PostsController@createPost',
       'as' => 'post_create',
       'middleware' => 'auth'
    ]);
    
    Route::post('/like', [
        'uses' => 'PostsController@likePost',
        'as' => 'post_like',
        'middleware' => 'auth'
    ]);
     
     Route::post('/edit', [
        'uses' => 'PostsController@editPost',
        'as' => 'post_edit',
        'middleware' => 'auth'
     ]);
        //function(\Illuminate\Http\Request $request){
        //return response()->json(['message' => $request['id']]);
        
     //});->name('edit');
     
     Route::get('/deletepost/{postID}', [
       'uses' => 'PostsController@deletePost',
       'as' => 'post_delete',
       'middleware' => 'auth'
    ]);
     
     
//});