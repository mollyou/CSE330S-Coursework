<?php $__env->startSection('title'); ?>
    Facebird
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Welcome to the Facebird:  the social media site for birds</h1>
        <?php echo $__env->make('messageoutput', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <!--Registration Form-->
            <div class="col-md-3">
                <h3>Register</h3>
                <form action="<?php echo e(route('register')); ?>" method="post">
                    <div class="form-group">
                        <label for="r_username">Username:  </label>
                        <input class="form-control" type="text" name="name" id="r_username" value="<?php echo e(Request::old('r_username')); ?>"> 
                    </div>
                    <div class="form-group">
                        <label for="r_password">Password (4-16 characters):  </label>
                        <input class="form-control" type="password" name="password" id="r_password"> 
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                </form>
            </div>
                
              
            <!--Sign In Form-->
            <div class="col-md-3">
                <h3>Sign In</h3>
                <form action="<?php echo e(route('signIn')); ?>" method="post">
                    <div class="form-group">
                        <label for="l_username">Username:  </label>
                        <input class="form-control" type="text" name="l_username" id="l_username"> 
                    </div>
                    <div class="form-group">
                        <label for="l_password">Password:  </label>
                        <input class="form-control" type="password" name="l_password" id="l_password"> 
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                </form>
            </div>
        
        <!--Show a cute bird pic-->
            <img src="<?php echo e(route('account_image', ['image.jpg'])); ?>" alt="" class="userimage">
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>