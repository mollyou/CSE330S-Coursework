<!--Dashboard Page-->


<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--For outputting error/success messages-->
    <?php echo $__env->make('messageoutput', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--Section for submitting a new post-->
    <div class="row new-post">
        <div class="col-md-6 col-md-offset-3">
            <header><h3>New Post</h3></header>
            <!--Form for a new post-->
                <form action="<?php echo e(route('post_create')); ?>" method="post">
                    <div class="form-group">
                        <textarea class="form-control" name="newPost" id="newPost" rows="5" placeholder="Say something!"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Post</button>
                        <!--Session Token-->
                    <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                </form>
        </div>
    </div>
        
    <!--Section displaying the newest posts in descending order-->
    <div class="row posts">
        <div class="col-md-6 col-md-offset-3">
            <header><h3>What's New</h3></header>
                <!--Go through all the posts passed to the page and display them-->
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <!--Save post ID as div ID-->
                    <div class="post" id="<?php echo e($post->id); ?>">
                        <!--Display the user image if they have one.  If not, use the default image-->
                            <?php if(Storage::disk('local')->has($post -> user -> id.'.png')): ?>
                               <img src=" <?php echo e(route('account_image', ['filename' => $post -> user -> id .'.png'])); ?>" alt="" class="avatar">
                            <?php else: ?>
                               <img src=" <?php echo e(route('account_image', ['default.png'])); ?>" alt="" class="avatar">
                            <?php endif; ?>
                        <!--Display post content-->
                        <p><?php echo e($post -> content); ?></p>
                            <!--Display post info + add link to user's page-->
                            <div class="info">
                                Posted by <a href="<?php echo e(route('viewuser', ['userV'=>$post->user->name])); ?>"><?php echo e($post -> user -> name); ?></a> on <?php echo e($post -> created_at); ?>

                            </div>
                            
                            <!--Display options to like, edit, delete-->
                            <div class="interaction">
                                <!--Likes and like count-->
                                <a href="#" class="like"><?php echo e(app\Http\Controllers\PostsController::beenLiked($post)); ?></a>
                                (+<p class="inline"><?php echo e(app\Http\Controllers\PostsController::getLikeCount($post)); ?></p>)
                                <!--Only give edit/delete options if the current user is the one that created the post-->
                                <?php if(Auth::user() == $post->user): ?>
                                    | 
                                    <a href="#" class="editbutt">Edit</a>
                                    | 
                                    <a href=" <?php echo e(route('post_delete', ['postID' => $post -> id ])); ?>">Delete</a>
                                <?php endif; ?>          
                            </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
    </div>
        
    <!--Modal for the post edit box-->
    <div class="modal fade" tabindex="-1" role="dialog" id="editPostModal">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Edit Post</h4>
            </div>
            <div class="modal-body">
              <form>
              <!--Textarea for editing-->
                  <div class="form-group">
                        <textarea class="form-control" name="editPost" id="editPost" rows="5"></textarea>
                  </div>
              </form>
            </div>
            <div class="modal-footer">
            <!--Buttons-->
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary" id="modal-save">Save changes</button>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->
      
      <!--Variables to get javascript stuff to work-->
      <script>
            var token = '<?php echo e(Session::token()); ?>';
            var editurl = '<?php echo e(route('post_edit')); ?>';
            var likeurl = '<?php echo e(route('post_like')); ?>';
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>