<!--Profile page for a given user-->


<?php $__env->startSection('title'); ?>
    <?php echo e($user->name); ?>'s profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row new-post">
            <div class="col-md-5 col-md-offset-2">
            <!--Description-->
                <header><h3><?php echo e($user->name); ?>'s profile</h3></header>
                <!--If they have a desctipion, display it.  Otherwise, placeholder-->
                <div class="post">
                    <?php if($user->description): ?>
                        <?php echo e($user->description); ?>

                    <?php else: ?>
                        <i>No description yet</i>
                    <?php endif; ?>
                    
                </div>
            </div>
            <div class="col-md-4">
                <!--User image.  If they don't have one, show the default-->
                    <?php if(Storage::disk('local')->has($user -> id.'.png')): ?>
                        <img src=" <?php echo e(route('account_image', ['filename' => $user -> id .'.png'])); ?>" alt="" class="userimage">
                    <?php else: ?>
                        <img src=" <?php echo e(route('account_image', ['default.png'])); ?>" alt="" class="userimage">
                    <?php endif; ?>
            </div>
        </div>
    <!--Display their posts in decending order-->
    <div class="row posts">
        <div class="col-md-6 col-md-offset-3">
            <header><h3><?php echo e($user->name); ?>'s recent activity</h3></header>
                <!--Go through each post-->
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="post" id="<?php echo e($post->id); ?>">
                    <!--User avatar-->
                         <?php if(Storage::disk('local')->has($post -> user -> id.'.png')): ?>
                            <img src=" <?php echo e(route('account_image', ['filename' => $post -> user -> id .'.png'])); ?>" alt="" class="avatar">
                         <?php else: ?>
                            <img src=" <?php echo e(route('account_image', ['default.png'])); ?>" alt="" class="avatar">
                         <?php endif; ?>
                    <!--Post body-->
                        <p><?php echo e($post -> content); ?></p>
                    <!--Display post date and number of likes-->
                        <div class="info">
                            Posted on <?php echo e($post -> created_at); ?><br>
                            Likes: <p class="inline"><?php echo e(app\Http\Controllers\PostsController::getLikeCount($post)); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>