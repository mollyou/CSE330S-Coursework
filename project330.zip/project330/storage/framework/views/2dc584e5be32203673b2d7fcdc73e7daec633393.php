<!--Message Output-->
<!--Errors-->
<?php if(count($errors) > 0): ?>
        <div class="row">
            <div class="col-md-4 col-md-offset-4 error">
                <u1>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </u1>
            </div>
        </div>
<?php endif; ?>
<!--Success Messages-->
<?php if(Session::has('message')): ?>
        <div class="row">
            <div class="col-md-4 col-md-offset-4 success">
                <u1>
                    <?php echo e(Session::get('message')); ?>

                </u1>
            </div>
        </div>
<?php endif; ?>