<?php $__env->startSection('header'); ?>
    <title>WOOT HEADER</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>About</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>