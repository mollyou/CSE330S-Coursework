<!--Page to edit account settings-->


<?php $__env->startSection('title'); ?>
    Account Info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--Include message outputs for errors-->
    <?php echo $__env->make('messageoutput', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row new-post">
        <!--Col for name, description, and image upload-->
        <div class="col-md-5 col-md-offset-2">
            <header><h3>Your Account</h3></header>
                <b>Name:  </b><?php echo e($user->name); ?>

            <!--Form to update description and image-->
                <form action="<?php echo e(route('account_save')); ?>" method="post" enctype="multipart/form-data">
                    <!--User Description-->
                        <div class="form-group">
                            <label for="image">About You </label>
                            <textarea class="form-control" name="description" id="description" rows="5"><?php echo e($user->description); ?></textarea>
                        </div>
                    <!--upload a user image-->
                        <div class="form-group">
                            <label for="image">Upload a new Image </label> (.png only, max 200kb)
                            <input type="file" name="image" id="image" class="form-control">
                        </div>
                    <button type="submit" class="btn btn-primary">Save</button>
                    <!--Pass Token-->
                    <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                </form>
        </div>
            <!--Display current image-->
                    <div class="col-md-4">
                        <b>Current Image</b><br>
                        <?php if(Storage::disk('local')->has($user -> id.'.png')): ?>
                               <img src=" <?php echo e(route('account_image', ['filename' => $user -> id .'.png'])); ?>" alt="" class="userimage">
                            <?php else: ?>
                               <img src=" <?php echo e(route('account_image', ['default.png'])); ?>" alt="" class="userimage">
                            <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>