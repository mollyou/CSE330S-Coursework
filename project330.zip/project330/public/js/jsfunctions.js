var post_ID = 0;
var postHTMLElement = null;

//birng up the edit modal upon clicking on a post's edit button
$('.post').find('.editbutt').on('click', function(event){
    event.preventDefault();
    
    //get the post contents and put them in the edit box
    postHTMLElement = event.target.parentNode.parentNode.childNodes[7];
    var postContent = postHTMLElement.textContent;
    $('#editPost').val(postContent);
    
    //get the post id
    post_ID = event.target.parentNode.parentNode.id;
    
    //bring up the modal
    $('#editPostModal').modal();
});

//save edits to a post
$('#modal-save').on('click', function(){
    //pass the info via ajax
    $.ajax({
        method: 'POST',
        url: editurl,
        data: { content: $('#editPost').val(),
                id: post_ID,
                _token: token}
    }).done(function (update) {
            //when finished, update the post on the dashboard and close the edit box
            $(postHTMLElement).text(update.updated_content);
            $('#editPostModal').modal('hide');
        });
});

//like/unlike a post upon clicking a button
$('.like').on('click', function(event){
    event.preventDefault();
    //get the post ID
    post_ID = event.target.parentNode.parentNode.id;
    //send the info vis ajax
    $.ajax({
        method: 'POST',
        url: likeurl,
        data: { postid: post_ID,
                _token: token}   
    }).done(function(){
        //upon response, update the html on the dashboard
        //get the current count
        var count=event.target.parentNode.childNodes[5].innerText;
        //if the post was liked, change the option to 'unlike' and increment the counter
        if(event.target.innerText =='Like'){
            event.target.innerText = 'Unlike';
            count++;
        }
        //if the post was unliked, change the option to 'like' and decrement the count
        else if(event.target.innerText =='Unlike'){
            event.target.innerText = 'Like';
            count--;
        }
        //else, error
        else{
            event.target.innerText = 'Error';   
        }
        //update the like count on the page
        event.target.parentNode.childNodes[5].innerText=count;
    });
});

